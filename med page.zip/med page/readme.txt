to run the meds page 
either, download this folder or a release and open the meds.html file
(only actually require, meds.html meds.css meds.js for main functinality)

btw this was codded using Deepseek R1, ChatGPT-o3 mini, Gemini 2.0 flash with thinking experimental